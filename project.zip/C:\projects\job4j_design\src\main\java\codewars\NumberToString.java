package codewars;

public class NumberToString {
    public static String numberToString(int num) {
        return String.valueOf(num);
    }
}
