package codewars;

public class NoSpace {
    public static String noSpace(final String x) {
        return x.replace(" ", "");
    }
}
