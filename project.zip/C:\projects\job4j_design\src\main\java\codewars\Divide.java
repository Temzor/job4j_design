package codewars;

public class Divide {
    public static boolean divide(int weight) {
        return weight > 3 && weight % 2 == 0;
    }
}
