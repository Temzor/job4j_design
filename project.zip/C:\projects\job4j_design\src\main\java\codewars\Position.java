package codewars;

public class Position {
    public static String position(char alphabet) {
        return "Position of alphabet: " + ((int) alphabet - 96);
    }
}
