package codewars;

import java.util.Arrays;

public class LastSurvivor {
    public static String lastSurvivor(String letters, int[] coords) {
        return String.format("letters: %s coords: %s", letters, Arrays.toString(coords));
    }
}
