package codewars;

public class MakeNegative {
    public static int makeNegative(final int x) {

        return x <= 0 ? x : -x;

    }
}

