package black.stream;

public enum Position {
    MANAGER, WORKER, CHEF
}