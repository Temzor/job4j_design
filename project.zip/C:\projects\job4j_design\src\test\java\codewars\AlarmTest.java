package codewars;

import codewars.Alarm;
import org.junit.Test;

import static org.junit.Assert.*;

public class AlarmTest {
    @Test
    public void setAlarmTest() {
        assertTrue("Should be true.", true);
        assertFalse("Should be false.", false);
        assertFalse("Should be false.", false);
        assertFalse("Should be false.", false);
    }

}