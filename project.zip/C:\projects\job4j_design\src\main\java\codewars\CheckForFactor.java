package codewars;

public class CheckForFactor {
    public static boolean checkForFactor(int base, int factor) {
        return base % factor == 0;
    }
}
