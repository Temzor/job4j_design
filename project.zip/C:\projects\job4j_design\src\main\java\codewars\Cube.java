package codewars;

public class Cube {
    private int side;

    public int getSide() {
        return side;
    }

    public void setSide(int num) {
        this.side = num;
    }
}
