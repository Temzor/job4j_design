package codewars;

public class AngleSum {
    public static int sumOfAngles(int n) {
        return 180 * (n - 2);
    }
}
