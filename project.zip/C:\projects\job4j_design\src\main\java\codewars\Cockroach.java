package codewars;

public class Cockroach {
    public int cockroachSpeed(double x) {
        return (int) Math.floor(x / 0.036);
    }
}
