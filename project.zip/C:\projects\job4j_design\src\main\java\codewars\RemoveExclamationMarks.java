package codewars;

public class RemoveExclamationMarks {
    public static String removeExclamationMarks(String s) {
        return s.replaceAll("!", "");
    }
}
