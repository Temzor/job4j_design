package codewars;

public class NthEven {
    public static int nthEven(int n) {
        return n * 2 - 2;
    }
}
