package codewars;

public class MaxMultiple {
    public static int maxMultiple(int divisor, int bound) {
        return bound / divisor * divisor;
    }
}
