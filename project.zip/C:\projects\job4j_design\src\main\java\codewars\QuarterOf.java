package codewars;

public class QuarterOf {
    public static int quarterOf(int month) {
        return (int) Math.ceil(month / 3.);
    }
}
