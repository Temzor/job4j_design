package codewars;

public class Ball {
    public static int maxBall(int v0) {
        return (int) Math.round((v0 / 3.6) / 0.981);
    }
}