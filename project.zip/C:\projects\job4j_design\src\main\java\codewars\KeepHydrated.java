package codewars;

public class KeepHydrated {
    public int liters(double time)  {

        return (int) Math.floor(time / 2);
    }

}

