package codewars;

public class GetSum {
    public int getSum(int a, int b) {
        return (a + b) * (Math.abs(a - b) + 1) / 2;
        }
    }

