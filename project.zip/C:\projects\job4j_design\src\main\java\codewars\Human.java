package codewars;

public class Human {
}
