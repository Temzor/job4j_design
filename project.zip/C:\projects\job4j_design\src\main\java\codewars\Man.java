package codewars;

public class Man extends Human {
}
