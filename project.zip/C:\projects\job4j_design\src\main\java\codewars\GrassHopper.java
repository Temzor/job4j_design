package codewars;

public class GrassHopper {

    public static int summation(int n) {
        return  n * (n + 1) / 2;
    }
}