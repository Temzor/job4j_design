package codewars;

public class WilsonPrime {
    public static boolean amiwilson(double n) {
        return n == 5 || n == 13 || n == 563;
    }
}

