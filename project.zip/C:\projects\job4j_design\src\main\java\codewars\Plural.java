package codewars;

public class Plural {
    public static boolean isPlural(float f) {
        return f != 1;
    }
}
