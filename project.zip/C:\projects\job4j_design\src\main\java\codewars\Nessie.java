package codewars;

public class Nessie {
    public static boolean isLockNessMonster(String s) {
        return s.contains("tree fiddy") || s.contains("3.50") || s.contains("three fifty");
    }
}
