package codewars;

public class FirstClass {
    public static byte sum(byte a, byte b) {
        return (byte) (a + b);
    }
}
