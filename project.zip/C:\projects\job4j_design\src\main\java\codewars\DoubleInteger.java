package codewars;

public class DoubleInteger {
    public static int doubleInteger(int i) {
        return i * 2;
    }
}
