package black.game;

public class Scholar extends Participant {

    public Scholar(String name, int age) {
        super(name, age);
    }
}
