package codewars;

public class Ascii {
    public static char getChar(int c) {
        return (char) c;
    }
}
