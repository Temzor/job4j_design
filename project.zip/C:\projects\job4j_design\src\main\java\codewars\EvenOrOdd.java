package codewars;

public class EvenOrOdd {
    public static String ever(int number) {
        return number % 2 == 0 ? "Even" : "Odd";
    }
}