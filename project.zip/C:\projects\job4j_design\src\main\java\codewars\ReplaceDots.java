package codewars;

public class ReplaceDots {
    public static String replaceDots(final String str) {
        return str.replaceAll("\\.", "-");
    }
}
