package codewars;


public class OddCount {
    public static int oddCount(int n) {
        return n / 2;
    }
}
