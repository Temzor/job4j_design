package codewars;

public class StringToArray {
    public static String[] stringToArray(String s) {
        return s.split(" ");
    }
}
