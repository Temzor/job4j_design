package codewars;

import java.util.Collections;

public class KataExampleTwist {
    public static String[] kataExampleTwist() {
        String[] websites = {};
        return Collections.nCopies(1000, "codewars").toArray(websites);
    }
}
