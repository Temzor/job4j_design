package codewars;

public class Bio {
    public String dnaToRna(String dna) {
        return dna.replace("T", "U");
    }
}
