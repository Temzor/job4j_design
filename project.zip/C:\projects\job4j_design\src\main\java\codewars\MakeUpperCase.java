package codewars;


public class MakeUpperCase {
    public static String makeUpperCase(String str) {
        return str.toUpperCase();
    }
}
