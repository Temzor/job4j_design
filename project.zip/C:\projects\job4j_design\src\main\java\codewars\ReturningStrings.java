package codewars;

public class ReturningStrings {
    public static String greet(String name) {
        return "Hello, " + name + " how are you doing today?";
    }
}
