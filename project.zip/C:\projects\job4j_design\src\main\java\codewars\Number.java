package codewars;

public class Number {
    public boolean isEven(double n) {
        return n % 2 == 0;
    }
}
