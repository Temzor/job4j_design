package codewars;

import java.util.stream.IntStream;

public class Triangular {
    public static int triangular(int n) {
        System.out.println(IntStream.range(1, n + 1).sum());
        return IntStream.range(1, n + 1).sum();

    }
}
