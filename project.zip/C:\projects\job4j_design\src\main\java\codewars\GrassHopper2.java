package codewars;

public class GrassHopper2 {
    public static String sayHello(String name) {
        return "Hello, " + name;
    }
}
