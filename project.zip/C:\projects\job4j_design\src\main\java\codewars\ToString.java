package codewars;

public class ToString {
    public static final String A = Integer.toString(123);
}
