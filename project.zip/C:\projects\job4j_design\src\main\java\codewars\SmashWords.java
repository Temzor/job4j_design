package codewars;

public class SmashWords {
    public static String smash(String... words) {
        return String.join(" ", words);
}
}
