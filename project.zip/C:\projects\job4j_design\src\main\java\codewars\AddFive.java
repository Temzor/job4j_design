package codewars;

public class AddFive {
    public static int addFive(int num) {
        return num + 5;
    }
}
