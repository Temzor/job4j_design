package leetcode.easy;

public class ListNode {
    int val;
    ListNode next;
    ListNode(int i, int i1, int i2) {}
    ListNode(int val) { this.val = val; }
    ListNode(int val, ListNode next) { this.val = val; this.next = next; }
  }