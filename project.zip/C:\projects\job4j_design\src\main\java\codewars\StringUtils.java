package codewars;

public class StringUtils {
    public static boolean isDigit(String s) {
        return s.matches("[0-9]");
    }
}
