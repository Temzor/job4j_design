package codewars;

public class Xor {
    public static boolean xor(boolean a, boolean b) {
        return a ^ b;
    }
}
