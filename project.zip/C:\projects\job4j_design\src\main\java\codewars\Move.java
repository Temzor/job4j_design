package codewars;

public class Move {
    public static int move(int position, int roll) {
        return position + roll * 2;
    }
}
