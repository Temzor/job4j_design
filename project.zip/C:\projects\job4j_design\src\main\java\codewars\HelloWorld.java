package codewars;

public class HelloWorld {
    public static String greet() {
        return "hello world!";
    }
}
