package codewars;

public class Century {
    public static int century(int number) {
        return (number - 1) / 100 + 1;
    }
}
