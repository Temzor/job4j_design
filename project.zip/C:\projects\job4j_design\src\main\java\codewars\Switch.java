package codewars;

public class Switch {
    public static String switcheroo(String x) {
        return x.replace("a", "x").replace("b", "a").replace("x", "b");
    }
}
