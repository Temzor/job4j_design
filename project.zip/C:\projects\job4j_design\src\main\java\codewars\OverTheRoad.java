package codewars;

public class OverTheRoad {
    public static long overTheRoad(long address, long n) {
        return n * 2 - address + 1;
    }
}
