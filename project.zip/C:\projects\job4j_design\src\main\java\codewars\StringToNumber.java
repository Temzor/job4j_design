package codewars;

public class StringToNumber {
    public static int stringToNumber(String str) {
        return Integer.parseInt(str);
    }
}
