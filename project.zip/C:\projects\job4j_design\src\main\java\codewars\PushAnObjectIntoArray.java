package codewars;

import java.util.ArrayList;

public class PushAnObjectIntoArray {
    public static ArrayList<String> push() {
        ArrayList<String> items = new ArrayList<>();
        items.add("an object");
        return items;
    }
}
