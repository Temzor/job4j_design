package codewars;

public class Opposite {
    public static int opposite(int number) {
        return -number;
    }
}

