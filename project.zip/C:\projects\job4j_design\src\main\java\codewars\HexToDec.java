package codewars;

public class HexToDec {
    public static int hexToDec(final String hexString) {
        return Integer.parseInt(hexString, 16);
    }
}
