package codewars;

import java.nio.ByteBuffer;

public class BitCounting {
    public static int countBits(int n) {
        return Integer.bitCount(n);
    }
}
