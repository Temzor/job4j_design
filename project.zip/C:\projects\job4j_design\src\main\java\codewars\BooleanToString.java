package codewars;

public class BooleanToString {
    public static String convert(boolean b) {
        return b ? "true" : "false";
    }
}
