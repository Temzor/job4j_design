# job4j_design
[![Build Status](https://travis-ci.com/Temzor/job4j_design.svg?branch=master)](https://travis-ci.com/Temzor/job4j_design)
[![codecov](https://codecov.io/gh/Temzor/job4j_design/branch/master/graph/badge.svg?token=NUQIJHD3RL)](https://codecov.io/gh/Temzor/job4j_design)